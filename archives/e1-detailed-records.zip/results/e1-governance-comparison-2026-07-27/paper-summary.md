# E1 Governance Comparison Results

## Aggregate condition-level results

| Condition | Benign completion | Unsafe execution | Detection recall | Containment success | False-positive rate | Evidence completeness | Preservation accuracy |
|---|---:|---:|---:|---:|---:|---:|---:|
| C0 Logging only | 100.00% | 100.00% | 0.00% | 0.00% | 0.00% | 34.72% | 50.00% |
| C1 Post-hoc governance | 100.00% | 100.00% | 100.00% | 0.00% | 0.00% | 100.00% | 100.00% |
| C2 Action-level pre-execution | 100.00% | 62.50% | 37.50% | 37.50% | 0.00% | 86.11% | 68.75% |
| C3 Organizational pre-execution | 100.00% | 0.00% | 100.00% | 100.00% | 0.00% | 100.00% | 100.00% |

## Result interpretation

C0 executed 100.0% of unsafe proposals and provided neither violation detection nor preventive containment.

C1 detected 100.0% of unsafe proposals, but still executed 100.0% because its governance decision was applied only after execution.

C2 reduced unsafe execution to 62.5% and contained 37.5% of unsafe cases. This reflects successful enforcement of action-local predicates while leaving context-dependent violations uncontained.

C3 reduced unsafe execution to 0.0%, achieved 100.0% detection recall and 100.0% containment, while maintaining 100.0% benign completion and a 0.0% false-positive rate.

Evidence completeness increased from 34.72% under C0 to 100.00% under C3. Preservation-directive accuracy increased from 50.00% under C0 to 100.00% under C3.

## Reproducibility

The experiment comprised 320 governed runs: 16 scenarios across 4 conditions and 5 deterministic repetitions.

All scenario-condition outcomes were identical across repetitions: `all_consistent = true`; `inconsistent_run_count = 0`.

The zero standard deviations therefore establish deterministic replay consistency for the fixed scenario suite. They should not be interpreted as sampling uncertainty estimates or evidence of robustness to stochastic model variation.
